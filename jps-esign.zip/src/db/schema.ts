import { integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  tool: text("tool").notNull(),
  pages: integer("pages"),
  sizeBytes: integer("size_bytes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const signatures = pgTable("signatures", {
  id: serial("id").primaryKey(),
  label: text("label").notNull(),
  dataUrl: text("data_url").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type DocumentRow = typeof documents.$inferSelect;
export type SignatureRow = typeof signatures.$inferSelect;
