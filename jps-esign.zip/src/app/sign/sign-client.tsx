"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { PDFDocument } from "pdf-lib";
import { Button, Card, Dropzone } from "@/components/ui";
import { SignaturePad } from "@/components/signature-pad";
import {
  downloadBlob,
  loadPdfDocument,
  logActivity,
  renderPageToDataUrl,
} from "@/lib/pdf-client";

type PageImage = { url: string; width: number; height: number };

type Placement = {
  id: string;
  page: number;
  x: number; // ratio of page width (left edge)
  y: number; // ratio of page height (top edge)
  w: number; // ratio of page width
  ratio: number; // image height / width
  dataUrl: string;
};

type SavedSignature = { id: number; label: string; dataUrl: string };

function imageRatio(dataUrl: string): Promise<number> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img.height / img.width);
    img.onerror = () => resolve(0.3);
    img.src = dataUrl;
  });
}

function makeTextImage(text: string): string {
  const canvas = document.createElement("canvas");
  canvas.width = 600;
  canvas.height = 120;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#1c1917";
  ctx.font = "44px Georgia, serif";
  ctx.textBaseline = "middle";
  ctx.textAlign = "center";
  ctx.fillText(text, canvas.width / 2, canvas.height / 2);
  return canvas.toDataURL("image/png");
}

export function SignClient() {
  const [file, setFile] = useState<File | null>(null);
  const [bytes, setBytes] = useState<ArrayBuffer | null>(null);
  const [pages, setPages] = useState<PageImage[]>([]);
  const [loading, setLoading] = useState(false);
  const [placements, setPlacements] = useState<Placement[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [saved, setSaved] = useState<SavedSignature[]>([]);
  const [current, setCurrent] = useState<{ dataUrl: string; ratio: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const pageRefs = useRef<(HTMLDivElement | null)[]>([]);
  const dragging = useRef<{ id: string; dx: number; dy: number; page: number } | null>(null);

  const refreshSignatures = useCallback(async () => {
    try {
      const res = await fetch("/api/signatures");
      const data = (await res.json()) as { signatures: SavedSignature[] };
      setSaved(data.signatures ?? []);
    } catch {
      setSaved([]);
    }
  }, []);

  useEffect(() => {
    void refreshSignatures();
  }, [refreshSignatures]);

  const openFile = useCallback(async (incoming: File) => {
    setLoading(true);
    setStatus(null);
    setPlacements([]);
    try {
      const buffer = await incoming.arrayBuffer();
      const pdf = await loadPdfDocument(buffer);
      const rendered: PageImage[] = [];
      for (let i = 1; i <= pdf.numPages; i += 1) {
        rendered.push(await renderPageToDataUrl(pdf, i, 1000));
      }
      setBytes(buffer);
      setFile(incoming);
      setPages(rendered);
    } catch {
      setStatus("Could not read that PDF.");
    } finally {
      setLoading(false);
    }
  }, []);

  const useSignature = async (dataUrl: string) => {
    setCurrent({ dataUrl, ratio: await imageRatio(dataUrl) });
    setStatus("Signature ready — click on a page to place it.");
  };

  const saveSignature = async (dataUrl: string) => {
    await fetch("/api/signatures", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ label: `Signature ${saved.length + 1}`, dataUrl }),
    });
    await refreshSignatures();
  };

  const placeOnPage = (pageIndex: number, event: React.MouseEvent<HTMLDivElement>) => {
    if (!current) {
      setStatus("Create or pick a signature first.");
      return;
    }
    const rect = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width;
    const y = (event.clientY - rect.top) / rect.height;
    const w = 0.25;
    const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    setPlacements((prev) => [
      ...prev,
      {
        id,
        page: pageIndex,
        x: Math.max(0, Math.min(1 - w, x - w / 2)),
        y: Math.max(0, Math.min(0.98, y - 0.03)),
        w,
        ratio: current.ratio,
        dataUrl: current.dataUrl,
      },
    ]);
    setActive(id);
  };

  const onPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragging.current;
    if (!drag) return;
    const container = pageRefs.current[drag.page];
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - drag.dx;
    const y = (event.clientY - rect.top) / rect.height - drag.dy;
    setPlacements((prev) =>
      prev.map((p) =>
        p.id === drag.id
          ? { ...p, x: Math.max(0, Math.min(1 - p.w, x)), y: Math.max(0, Math.min(1, y)) }
          : p,
      ),
    );
  };

  const resize = (id: string, delta: number) =>
    setPlacements((prev) =>
      prev.map((p) =>
        p.id === id ? { ...p, w: Math.max(0.06, Math.min(0.9, p.w + delta)) } : p,
      ),
    );

  const apply = async () => {
    if (!bytes || !file) return;
    setBusy(true);
    setStatus(null);
    try {
      const pdfDoc = await PDFDocument.load(bytes.slice(0));
      const docPages = pdfDoc.getPages();
      for (const placement of placements) {
        const page = docPages[placement.page];
        if (!page) continue;
        const { width: pw, height: ph } = page.getSize();
        const png = await pdfDoc.embedPng(placement.dataUrl);
        const drawWidth = placement.w * pw;
        const drawHeight = drawWidth * placement.ratio;
        page.drawImage(png, {
          x: placement.x * pw,
          y: ph - placement.y * ph - drawHeight,
          width: drawWidth,
          height: drawHeight,
        });
      }
      const out = await pdfDoc.save();
      const name = file.name.replace(/\.pdf$/i, "") + "-signed.pdf";
      downloadBlob(out, name);
      await logActivity({
        name,
        tool: "e-sign",
        pages: docPages.length,
        sizeBytes: out.byteLength,
      });
      setStatus(`Saved ${name}`);
    } catch {
      setStatus("Something went wrong while signing.");
    } finally {
      setBusy(false);
    }
  };

  if (!file) {
    return (
      <div className="flex flex-col gap-6">
        <Dropzone onFiles={(files) => void openFile(files[0])} label="Drop the PDF to sign" />
        {loading && <p className="text-sm text-stone-500">Rendering pages…</p>}
        {status && <p className="text-sm text-stone-500">{status}</p>}
      </div>
    );
  }

  return (
    <div
      className="grid gap-8 lg:grid-cols-[1fr_320px]"
      onPointerMove={onPointerMove}
      onPointerUp={() => {
        dragging.current = null;
      }}
    >
      <div className="flex flex-col gap-6">
        {pages.map((page, index) => (
          <div
            key={index}
            ref={(el) => {
              pageRefs.current[index] = el;
            }}
            onClick={(e) => placeOnPage(index, e)}
            className="relative overflow-hidden rounded-xl border border-stone-200 bg-white shadow-sm"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={page.url} alt={`Page ${index + 1}`} className="w-full select-none" />
            <span className="absolute left-3 top-3 rounded-full bg-stone-900/70 px-2 py-0.5 text-[10px] text-stone-50">
              {index + 1}
            </span>
            {placements
              .filter((p) => p.page === index)
              .map((p) => (
                <div
                  key={p.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    setActive(p.id);
                  }}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    const rect = pageRefs.current[index]!.getBoundingClientRect();
                    dragging.current = {
                      id: p.id,
                      page: index,
                      dx: (e.clientX - rect.left) / rect.width - p.x,
                      dy: (e.clientY - rect.top) / rect.height - p.y,
                    };
                    setActive(p.id);
                  }}
                  style={{
                    left: `${p.x * 100}%`,
                    top: `${p.y * 100}%`,
                    width: `${p.w * 100}%`,
                  }}
                  className={`absolute cursor-move touch-none rounded ${
                    active === p.id ? "ring-2 ring-stone-900/60" : "ring-1 ring-transparent"
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={p.dataUrl} alt="signature" className="w-full select-none" draggable={false} />
                </div>
              ))}
          </div>
        ))}
      </div>

      <aside className="flex h-fit flex-col gap-4 lg:sticky lg:top-24">
        <Card>
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm font-medium">{file.name}</p>
              <p className="text-xs text-stone-500">{pages.length} pages</p>
            </div>
            <button
              onClick={() => {
                setFile(null);
                setPages([]);
                setBytes(null);
                setPlacements([]);
              }}
              className="text-xs text-stone-500 underline-offset-4 hover:underline"
            >
              Change
            </button>
          </div>
        </Card>

        <Card>
          <h2 className="mb-3 text-xs font-medium uppercase tracking-[0.2em] text-stone-400">
            Your signature
          </h2>
          <SignaturePad
            onCreate={async (dataUrl) => {
              await useSignature(dataUrl);
              await saveSignature(dataUrl);
            }}
          />
        </Card>

        {saved.length > 0 && (
          <Card>
            <h2 className="mb-3 text-xs font-medium uppercase tracking-[0.2em] text-stone-400">
              Saved
            </h2>
            <div className="grid grid-cols-2 gap-2">
              {saved.map((sig) => (
                <button
                  key={sig.id}
                  onClick={() => void useSignature(sig.dataUrl)}
                  className={`rounded-lg border p-2 transition hover:border-stone-900 ${
                    current?.dataUrl === sig.dataUrl ? "border-stone-900" : "border-stone-200"
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={sig.dataUrl} alt={sig.label} className="h-10 w-full object-contain" />
                </button>
              ))}
            </div>
          </Card>
        )}

        <Card>
          <h2 className="mb-3 text-xs font-medium uppercase tracking-[0.2em] text-stone-400">
            Placement
          </h2>
          {placements.length === 0 ? (
            <p className="text-xs text-stone-500">
              Pick a signature, then click on the page to drop it. Drag to reposition.
            </p>
          ) : (
            <div className="flex flex-col gap-2 text-xs">
              {placements.map((p, i) => (
                <div key={p.id} className="flex items-center justify-between gap-2">
                  <span className="text-stone-600">
                    #{i + 1} · page {p.page + 1}
                  </span>
                  <span className="flex items-center gap-1">
                    <button
                      onClick={() => resize(p.id, -0.03)}
                      className="h-6 w-6 rounded-full border border-stone-200 hover:border-stone-900"
                    >
                      −
                    </button>
                    <button
                      onClick={() => resize(p.id, 0.03)}
                      className="h-6 w-6 rounded-full border border-stone-200 hover:border-stone-900"
                    >
                      +
                    </button>
                    <button
                      onClick={() => setPlacements((prev) => prev.filter((x) => x.id !== p.id))}
                      className="h-6 w-6 rounded-full border border-stone-200 hover:border-stone-900"
                    >
                      ×
                    </button>
                  </span>
                </div>
              ))}
            </div>
          )}
          <div className="mt-4 flex flex-col gap-2">
            <Button
              variant="outline"
              onClick={() =>
                void useSignature(makeTextImage(new Date().toLocaleDateString()))
              }
            >
              Add today&rsquo;s date stamp
            </Button>
            <Button onClick={apply} disabled={busy || placements.length === 0}>
              {busy ? "Signing…" : "Download signed PDF"}
            </Button>
          </div>
          {status && <p className="mt-3 text-xs text-stone-500">{status}</p>}
        </Card>
      </aside>
    </div>
  );
}
