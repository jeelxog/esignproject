import { SignClient } from "./sign-client";

export const metadata = {
  title: "E-sign a PDF — jp's pdfs",
};

export default function SignPage() {
  return (
    <div className="flex flex-col gap-8">
      <header>
        <p className="text-xs uppercase tracking-[0.25em] text-stone-400">e-signature</p>
        <h1 className="mt-3 text-3xl font-medium tracking-tight">Sign a document</h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-stone-600">
          Upload a PDF, draw or type your signature, then drop it exactly where it
          belongs. Everything happens locally in your browser.
        </p>
      </header>
      <SignClient />
    </div>
  );
}
