import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { documents, type DocumentRow } from "@/db/schema";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Activity — jp's pdfs",
};

function bytes(size?: number | null) {
  if (size === null || size === undefined) return "—";
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(2)} MB`;
}

export default async function ActivityPage() {
  let rows: DocumentRow[] = [];
  try {
    rows = await db.select().from(documents).orderBy(desc(documents.createdAt)).limit(50);
  } catch {
    rows = [];
  }

  return (
    <div className="flex flex-col gap-8">
      <header>
        <p className="text-xs uppercase tracking-[0.25em] text-stone-400">history</p>
        <h1 className="mt-3 text-3xl font-medium tracking-tight">Activity</h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-stone-600">
          A lightweight log of documents you have produced. Only file names and
          sizes are recorded — never the file contents.
        </p>
      </header>

      {rows.length === 0 ? (
        <div className="grain rounded-2xl border border-dashed border-stone-300 px-6 py-16 text-center">
          <p className="text-sm text-stone-600">Nothing here yet.</p>
          <Link
            href="/sign"
            className="mt-4 inline-block rounded-full bg-stone-900 px-4 py-2 text-sm text-stone-50 transition hover:bg-stone-700"
          >
            Sign your first document
          </Link>
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl border border-stone-200 bg-white/70">
          <table className="w-full text-left text-sm">
            <thead className="bg-stone-50 text-[11px] uppercase tracking-wider text-stone-400">
              <tr>
                <th className="px-5 py-3 font-medium">File</th>
                <th className="px-5 py-3 font-medium">Tool</th>
                <th className="px-5 py-3 font-medium">Pages</th>
                <th className="px-5 py-3 font-medium">Size</th>
                <th className="px-5 py-3 font-medium">When</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id} className="border-t border-stone-100">
                  <td className="max-w-[220px] truncate px-5 py-3 text-stone-800">{row.name}</td>
                  <td className="px-5 py-3">
                    <span className="rounded-full bg-stone-100 px-2.5 py-1 text-xs text-stone-600">
                      {row.tool}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-stone-500">{row.pages ?? "—"}</td>
                  <td className="px-5 py-3 text-stone-500">{bytes(row.sizeBytes)}</td>
                  <td className="px-5 py-3 text-stone-500">
                    {new Date(row.createdAt).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
