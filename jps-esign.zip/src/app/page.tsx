import Link from "next/link";

const tools = [
  { icon: "✍️", name: "E-sign", desc: "Draw or type a signature, place it anywhere.", href: "/sign" },
  { icon: "⇢", name: "Merge", desc: "Combine several PDFs into one file.", href: "/tools?tool=merge" },
  { icon: "✂︎", name: "Split", desc: "Extract a page range into a new PDF.", href: "/tools?tool=split" },
  { icon: "⟳", name: "Rotate", desc: "Turn pages 90°, 180° or 270°.", href: "/tools?tool=rotate" },
  { icon: "🖼", name: "Images → PDF", desc: "Turn JPG/PNG files into a document.", href: "/tools?tool=images" },
  { icon: "◈", name: "Watermark", desc: "Stamp diagonal text on every page.", href: "/tools?tool=watermark" },
  { icon: "№", name: "Page numbers", desc: "Add tidy numbering to the footer.", href: "/tools?tool=numbers" },
  { icon: "🗑", name: "Delete pages", desc: "Remove pages you don't need.", href: "/tools?tool=delete" },
];

export default function HomePage() {
  return (
    <div className="flex flex-col gap-16">
      <section className="pt-8">
        <p className="text-xs uppercase tracking-[0.25em] text-stone-400">
          documents, quietly handled
        </p>
        <h1 className="mt-5 max-w-2xl text-4xl font-medium leading-[1.1] tracking-tight text-stone-900 sm:text-6xl">
          Sign and shape your PDFs.
          <br />
          <span className="text-stone-400">Nothing leaves your device.</span>
        </h1>
        <p className="mt-6 max-w-xl text-sm leading-relaxed text-stone-600">
          jp&rsquo;s pdfs is a small, fast toolkit for electronic signatures and everyday
          PDF edits. Everything runs in your browser — we only keep a lightweight
          activity log so you can retrace your work.
        </p>
        <div className="mt-8 flex flex-wrap items-center gap-3">
          <Link
            href="/sign"
            className="rounded-full bg-stone-900 px-5 py-2.5 text-sm font-medium text-stone-50 transition hover:bg-stone-700"
          >
            Sign a document
          </Link>
          <Link
            href="/tools"
            className="rounded-full border border-stone-300 px-5 py-2.5 text-sm font-medium text-stone-800 transition hover:border-stone-900"
          >
            Browse tools
          </Link>
        </div>
      </section>

      <section>
        <div className="flex items-baseline justify-between">
          <h2 className="text-sm font-medium uppercase tracking-[0.2em] text-stone-400">
            Toolkit
          </h2>
          <span className="text-xs text-stone-400">{tools.length} tools</span>
        </div>
        <div className="mt-6 grid gap-px overflow-hidden rounded-2xl border border-stone-200 bg-stone-200 sm:grid-cols-2 lg:grid-cols-4">
          {tools.map((tool) => (
            <Link
              key={tool.name}
              href={tool.href}
              className="group flex min-h-[150px] flex-col justify-between bg-[#fbfaf8] p-5 transition hover:bg-white"
            >
              <span className="text-lg">{tool.icon}</span>
              <span>
                <span className="block text-sm font-medium text-stone-900">{tool.name}</span>
                <span className="mt-1 block text-xs leading-relaxed text-stone-500">
                  {tool.desc}
                </span>
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="grid gap-8 border-t border-stone-200 pt-10 sm:grid-cols-3">
        {[
          { t: "Private by design", d: "Rendering and editing happen locally with pdf.js and pdf-lib." },
          { t: "Reusable signatures", d: "Save a drawn or typed signature once and reuse it later." },
          { t: "Zero setup", d: "No accounts, no installs, no watermarks on your output." },
        ].map((item) => (
          <div key={item.t}>
            <h3 className="text-sm font-medium text-stone-900">{item.t}</h3>
            <p className="mt-2 text-xs leading-relaxed text-stone-500">{item.d}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
