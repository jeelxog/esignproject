import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { signatures } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select()
      .from(signatures)
      .orderBy(desc(signatures.createdAt))
      .limit(12);
    return NextResponse.json({ signatures: rows });
  } catch {
    return NextResponse.json({ signatures: [] });
  }
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as
    | { label?: string; dataUrl?: string }
    | null;

  if (!body?.dataUrl?.startsWith("data:image/")) {
    return NextResponse.json({ error: "dataUrl is required" }, { status: 400 });
  }

  try {
    const [row] = await db
      .insert(signatures)
      .values({
        label: (body.label || "Signature").slice(0, 60),
        dataUrl: body.dataUrl,
      })
      .returning();
    return NextResponse.json({ signature: row }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "could not save signature" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isFinite(id)) {
    return NextResponse.json({ error: "id is required" }, { status: 400 });
  }
  try {
    await db.delete(signatures).where(eq(signatures.id, id));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "could not delete" }, { status: 500 });
  }
}
