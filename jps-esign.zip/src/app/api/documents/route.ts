import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { documents } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select()
      .from(documents)
      .orderBy(desc(documents.createdAt))
      .limit(50);
    return NextResponse.json({ documents: rows });
  } catch {
    return NextResponse.json({ documents: [] });
  }
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as
    | { name?: string; tool?: string; pages?: number; sizeBytes?: number }
    | null;

  if (!body?.name || !body?.tool) {
    return NextResponse.json({ error: "name and tool are required" }, { status: 400 });
  }

  try {
    const [row] = await db
      .insert(documents)
      .values({
        name: body.name.slice(0, 180),
        tool: body.tool.slice(0, 60),
        pages: Number.isFinite(body.pages) ? Number(body.pages) : null,
        sizeBytes: Number.isFinite(body.sizeBytes) ? Math.round(Number(body.sizeBytes)) : null,
      })
      .returning();
    return NextResponse.json({ document: row }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "could not save activity" }, { status: 500 });
  }
}
