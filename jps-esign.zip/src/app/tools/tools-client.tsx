"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { PDFDocument, StandardFonts, degrees, rgb } from "pdf-lib";
import { Button, Card, Dropzone, Field, inputClass } from "@/components/ui";
import { downloadBlob, formatBytes, logActivity, parsePageRanges } from "@/lib/pdf-client";

type ToolId =
  | "merge"
  | "split"
  | "delete"
  | "rotate"
  | "images"
  | "watermark"
  | "numbers"
  | "info";

const TOOLS: { id: ToolId; name: string; icon: string; blurb: string; multiple: boolean; accept: string }[] = [
  { id: "merge", name: "Merge", icon: "⇢", blurb: "Combine PDFs in order.", multiple: true, accept: "application/pdf" },
  { id: "split", name: "Split", icon: "✂︎", blurb: "Keep only chosen pages.", multiple: false, accept: "application/pdf" },
  { id: "delete", name: "Delete pages", icon: "🗑", blurb: "Remove chosen pages.", multiple: false, accept: "application/pdf" },
  { id: "rotate", name: "Rotate", icon: "⟳", blurb: "Turn pages by 90° steps.", multiple: false, accept: "application/pdf" },
  { id: "images", name: "Images → PDF", icon: "🖼", blurb: "JPG / PNG to one PDF.", multiple: true, accept: "image/png,image/jpeg" },
  { id: "watermark", name: "Watermark", icon: "◈", blurb: "Diagonal text stamp.", multiple: false, accept: "application/pdf" },
  { id: "numbers", name: "Page numbers", icon: "№", blurb: "Footer numbering.", multiple: false, accept: "application/pdf" },
  { id: "info", name: "Inspect", icon: "ℹ", blurb: "Metadata & page sizes.", multiple: false, accept: "application/pdf" },
];

export function ToolsClient() {
  const params = useSearchParams();
  const initial = (params.get("tool") as ToolId) || "merge";
  const [toolId, setToolId] = useState<ToolId>(
    TOOLS.some((t) => t.id === initial) ? initial : "merge",
  );
  const [files, setFiles] = useState<File[]>([]);
  const [range, setRange] = useState("1-1");
  const [rotation, setRotation] = useState(90);
  const [watermark, setWatermark] = useState("CONFIDENTIAL");
  const [opacity, setOpacity] = useState(0.15);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [report, setReport] = useState<string[]>([]);

  const tool = useMemo(() => TOOLS.find((t) => t.id === toolId)!, [toolId]);

  const reset = (id: ToolId) => {
    setToolId(id);
    setFiles([]);
    setStatus(null);
    setReport([]);
  };

  const run = async () => {
    if (files.length === 0) {
      setStatus("Add a file first.");
      return;
    }
    setBusy(true);
    setStatus(null);
    setReport([]);
    try {
      if (toolId === "images") {
        const doc = await PDFDocument.create();
        for (const file of files) {
          const bytes = new Uint8Array(await file.arrayBuffer());
          const image = file.type.includes("png")
            ? await doc.embedPng(bytes)
            : await doc.embedJpg(bytes);
          const page = doc.addPage([image.width, image.height]);
          page.drawImage(image, { x: 0, y: 0, width: image.width, height: image.height });
        }
        const out = await doc.save();
        downloadBlob(out, "images.pdf");
        await logActivity({ name: "images.pdf", tool: "images-to-pdf", pages: files.length, sizeBytes: out.byteLength });
        setStatus(`Created images.pdf · ${formatBytes(out.byteLength)}`);
        return;
      }

      if (toolId === "merge") {
        const doc = await PDFDocument.create();
        let total = 0;
        for (const file of files) {
          const src = await PDFDocument.load(await file.arrayBuffer());
          const copied = await doc.copyPages(src, src.getPageIndices());
          copied.forEach((p) => doc.addPage(p));
          total += copied.length;
        }
        const out = await doc.save();
        downloadBlob(out, "merged.pdf");
        await logActivity({ name: "merged.pdf", tool: "merge", pages: total, sizeBytes: out.byteLength });
        setStatus(`Merged ${files.length} files · ${total} pages`);
        return;
      }

      const file = files[0];
      const src = await PDFDocument.load(await file.arrayBuffer());
      const count = src.getPageCount();
      const baseName = file.name.replace(/\.pdf$/i, "");

      if (toolId === "info") {
        const lines = [
          `Pages: ${count}`,
          `Size: ${formatBytes(file.size)}`,
          `Title: ${src.getTitle() || "—"}`,
          `Author: ${src.getAuthor() || "—"}`,
          `Producer: ${src.getProducer() || "—"}`,
          ...src.getPages().slice(0, 8).map((p, i) => {
            const { width, height } = p.getSize();
            return `Page ${i + 1}: ${Math.round(width)} × ${Math.round(height)} pt`;
          }),
        ];
        setReport(lines);
        setStatus("Inspection complete.");
        return;
      }

      if (toolId === "split" || toolId === "delete") {
        const selected = parsePageRanges(range, count);
        if (selected.length === 0) throw new Error("range");
        const keep =
          toolId === "split"
            ? selected.map((n) => n - 1)
            : Array.from({ length: count }, (_, i) => i).filter(
                (i) => !selected.includes(i + 1),
              );
        if (keep.length === 0) throw new Error("empty");
        const doc = await PDFDocument.create();
        const copied = await doc.copyPages(src, keep);
        copied.forEach((p) => doc.addPage(p));
        const out = await doc.save();
        const name = `${baseName}-${toolId === "split" ? "extract" : "trimmed"}.pdf`;
        downloadBlob(out, name);
        await logActivity({ name, tool: toolId, pages: keep.length, sizeBytes: out.byteLength });
        setStatus(`${name} · ${keep.length} pages`);
        return;
      }

      if (toolId === "rotate") {
        src.getPages().forEach((page) => {
          page.setRotation(degrees((page.getRotation().angle + rotation) % 360));
        });
        const out = await src.save();
        const name = `${baseName}-rotated.pdf`;
        downloadBlob(out, name);
        await logActivity({ name, tool: "rotate", pages: count, sizeBytes: out.byteLength });
        setStatus(`${name} · rotated ${rotation}°`);
        return;
      }

      if (toolId === "watermark") {
        const font = await src.embedFont(StandardFonts.HelveticaBold);
        src.getPages().forEach((page) => {
          const { width, height } = page.getSize();
          const size = Math.min(width, height) / 8;
          page.drawText(watermark || "DRAFT", {
            x: width * 0.12,
            y: height * 0.32,
            size,
            font,
            color: rgb(0.1, 0.1, 0.1),
            opacity,
            rotate: degrees(38),
          });
        });
        const out = await src.save();
        const name = `${baseName}-watermarked.pdf`;
        downloadBlob(out, name);
        await logActivity({ name, tool: "watermark", pages: count, sizeBytes: out.byteLength });
        setStatus(`${name} · ${count} pages stamped`);
        return;
      }

      if (toolId === "numbers") {
        const font = await src.embedFont(StandardFonts.Helvetica);
        src.getPages().forEach((page, index) => {
          const { width } = page.getSize();
          const label = `${index + 1} / ${count}`;
          const size = 10;
          page.drawText(label, {
            x: width / 2 - font.widthOfTextAtSize(label, size) / 2,
            y: 24,
            size,
            font,
            color: rgb(0.35, 0.33, 0.31),
          });
        });
        const out = await src.save();
        const name = `${baseName}-numbered.pdf`;
        downloadBlob(out, name);
        await logActivity({ name, tool: "page-numbers", pages: count, sizeBytes: out.byteLength });
        setStatus(`${name} · numbered ${count} pages`);
      }
    } catch {
      setStatus("That didn't work — check the file and options.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[220px_1fr]">
      <nav className="flex flex-wrap gap-1 lg:flex-col">
        {TOOLS.map((item) => (
          <button
            key={item.id}
            onClick={() => reset(item.id)}
            className={`flex items-center gap-2 rounded-xl px-3 py-2 text-left text-sm transition ${
              item.id === toolId
                ? "bg-stone-900 text-stone-50"
                : "text-stone-600 hover:bg-stone-900/5"
            }`}
          >
            <span className="w-4 text-center text-xs">{item.icon}</span>
            {item.name}
          </button>
        ))}
      </nav>

      <div className="flex flex-col gap-4">
        <Card>
          <h2 className="text-lg font-medium tracking-tight">{tool.name}</h2>
          <p className="mt-1 text-xs text-stone-500">{tool.blurb}</p>

          <div className="mt-5">
            <Dropzone
              accept={tool.accept}
              multiple={tool.multiple}
              onFiles={(incoming) =>
                setFiles(tool.multiple ? [...files, ...incoming] : [incoming[0]])
              }
              label={tool.multiple ? "Drop files here" : "Drop a file here"}
              hint={
                tool.id === "images"
                  ? "JPG or PNG — order follows the list below"
                  : "PDF only — processed locally"
              }
            />
          </div>

          {files.length > 0 && (
            <ul className="mt-4 flex flex-col gap-1.5">
              {files.map((file, index) => (
                <li
                  key={`${file.name}-${index}`}
                  className="flex items-center justify-between rounded-lg border border-stone-200 bg-white px-3 py-2 text-xs"
                >
                  <span className="truncate text-stone-700">{file.name}</span>
                  <span className="flex items-center gap-3 text-stone-400">
                    {formatBytes(file.size)}
                    <button
                      onClick={() => setFiles(files.filter((_, i) => i !== index))}
                      className="hover:text-stone-900"
                    >
                      ×
                    </button>
                  </span>
                </li>
              ))}
            </ul>
          )}

          {(toolId === "split" || toolId === "delete") && (
            <div className="mt-4 max-w-xs">
              <Field label="Pages">
                <input
                  value={range}
                  onChange={(e) => setRange(e.target.value)}
                  placeholder="e.g. 1-3, 5"
                  className={inputClass}
                />
              </Field>
            </div>
          )}

          {toolId === "rotate" && (
            <div className="mt-4 flex gap-2">
              {[90, 180, 270].map((deg) => (
                <button
                  key={deg}
                  onClick={() => setRotation(deg)}
                  className={`rounded-full border px-4 py-1.5 text-xs transition ${
                    rotation === deg
                      ? "border-stone-900 bg-stone-900 text-stone-50"
                      : "border-stone-300 text-stone-600 hover:border-stone-900"
                  }`}
                >
                  {deg}°
                </button>
              ))}
            </div>
          )}

          {toolId === "watermark" && (
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <Field label="Text">
                <input
                  value={watermark}
                  onChange={(e) => setWatermark(e.target.value)}
                  className={inputClass}
                />
              </Field>
              <Field label={`Opacity ${Math.round(opacity * 100)}%`}>
                <input
                  type="range"
                  min={5}
                  max={60}
                  value={Math.round(opacity * 100)}
                  onChange={(e) => setOpacity(Number(e.target.value) / 100)}
                  className="accent-stone-900"
                />
              </Field>
            </div>
          )}

          <div className="mt-6 flex items-center gap-3">
            <Button onClick={run} disabled={busy}>
              {busy ? "Working…" : toolId === "info" ? "Inspect" : "Run & download"}
            </Button>
            {files.length > 0 && (
              <Button variant="ghost" onClick={() => setFiles([])}>
                Clear
              </Button>
            )}
          </div>

          {status && <p className="mt-4 text-xs text-stone-500">{status}</p>}
        </Card>

        {report.length > 0 && (
          <Card>
            <h3 className="mb-3 text-xs font-medium uppercase tracking-[0.2em] text-stone-400">
              Document report
            </h3>
            <dl className="grid gap-1.5 text-xs text-stone-600 sm:grid-cols-2">
              {report.map((line) => (
                <div key={line} className="rounded-lg bg-stone-100/70 px-3 py-2">
                  {line}
                </div>
              ))}
            </dl>
          </Card>
        )}
      </div>
    </div>
  );
}
