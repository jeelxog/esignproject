import { Suspense } from "react";
import { ToolsClient } from "./tools-client";

export const metadata = {
  title: "PDF tools — jp's pdfs",
};

export default function ToolsPage() {
  return (
    <div className="flex flex-col gap-8">
      <header>
        <p className="text-xs uppercase tracking-[0.25em] text-stone-400">toolkit</p>
        <h1 className="mt-3 text-3xl font-medium tracking-tight">PDF tools</h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-stone-600">
          Merge, split, rotate, watermark and more — all processed on your own
          machine, then downloaded straight back to you.
        </p>
      </header>
      <Suspense fallback={<p className="text-sm text-stone-500">Loading tools…</p>}>
        <ToolsClient />
      </Suspense>
    </div>
  );
}
