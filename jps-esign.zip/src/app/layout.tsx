import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "JP's PDFs — minimal e-signing & PDF tools",
  description:
    "Sign, merge, split, rotate, watermark and convert PDFs right in your browser. Minimal, private, fast.",
};

const nav = [
  { href: "/sign", label: "Sign" },
  { href: "/tools", label: "Tools" },
  { href: "/activity", label: "Activity" },
];

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#fbfaf8] text-stone-900 antialiased selection:bg-stone-900 selection:text-stone-50">
        <header className="sticky top-0 z-40 border-b border-stone-200/70 bg-[#fbfaf8]/80 backdrop-blur">
          <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-6">
            <Link href="/" className="group flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-md bg-stone-900 text-[11px] font-semibold tracking-tight text-stone-50">
                JP
              </span>
              <span className="text-sm font-medium tracking-tight">
                jp&rsquo;s pdfs
              </span>
            </Link>
            <nav className="flex items-center gap-1">
              {nav.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="rounded-full px-3 py-1.5 text-sm text-stone-600 transition hover:bg-stone-900/5 hover:text-stone-900"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
        </header>
        <main className="mx-auto max-w-5xl px-6 pb-24 pt-10">{children}</main>
        <footer className="border-t border-stone-200/70">
          <div className="mx-auto flex max-w-5xl flex-col gap-1 px-6 py-8 text-xs text-stone-500 sm:flex-row sm:items-center sm:justify-between">
            <p>© {new Date().getFullYear()} jp&rsquo;s pdfs — files never leave your device.</p>
            <p>Built with pdf-lib &amp; pdf.js</p>
          </div>
        </footer>
      </body>
    </html>
  );
}
