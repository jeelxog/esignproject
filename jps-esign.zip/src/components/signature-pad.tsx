"use client";

import { useEffect, useRef, useState } from "react";
import { Button, inputClass } from "./ui";

type Mode = "draw" | "type";

const fonts = [
  { label: "Script", css: '42px "Snell Roundhand", "Segoe Script", cursive' },
  { label: "Serif", css: '38px Georgia, "Times New Roman", serif' },
  { label: "Sans", css: '36px Helvetica, Arial, sans-serif' },
];

export function SignaturePad({
  onCreate,
}: {
  onCreate: (dataUrl: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawing = useRef(false);
  const [mode, setMode] = useState<Mode>("draw");
  const [text, setText] = useState("");
  const [fontIndex, setFontIndex] = useState(0);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = 640;
    canvas.height = 200;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = "#1c1917";
  }, [mode]);

  useEffect(() => {
    if (mode !== "type") return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#1c1917";
    ctx.font = fonts[fontIndex].css;
    ctx.textBaseline = "middle";
    ctx.textAlign = "center";
    ctx.fillText(text, canvas.width / 2, canvas.height / 2);
    setDirty(text.trim().length > 0);
  }, [mode, text, fontIndex]);

  const pos = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((event.clientX - rect.left) / rect.width) * canvas.width,
      y: ((event.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const clear = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setDirty(false);
    setText("");
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-1 text-xs">
        {(["draw", "type"] as Mode[]).map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => {
              setMode(value);
              setDirty(false);
            }}
            className={`rounded-full px-3 py-1 capitalize transition ${
              mode === value
                ? "bg-stone-900 text-stone-50"
                : "text-stone-500 hover:bg-stone-900/5"
            }`}
          >
            {value}
          </button>
        ))}
        {mode === "type" && (
          <div className="ml-auto flex gap-1">
            {fonts.map((font, index) => (
              <button
                key={font.label}
                type="button"
                onClick={() => setFontIndex(index)}
                className={`rounded-full px-2.5 py-1 transition ${
                  index === fontIndex
                    ? "bg-stone-200 text-stone-900"
                    : "text-stone-500 hover:bg-stone-900/5"
                }`}
              >
                {font.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {mode === "type" && (
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Type your name"
          className={inputClass}
        />
      )}

      <canvas
        ref={canvasRef}
        onPointerDown={(e) => {
          if (mode !== "draw") return;
          drawing.current = true;
          const ctx = canvasRef.current!.getContext("2d")!;
          const p = pos(e);
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          e.currentTarget.setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => {
          if (!drawing.current || mode !== "draw") return;
          const ctx = canvasRef.current!.getContext("2d")!;
          const p = pos(e);
          ctx.lineTo(p.x, p.y);
          ctx.stroke();
          setDirty(true);
        }}
        onPointerUp={() => {
          drawing.current = false;
        }}
        className="h-[150px] w-full touch-none rounded-xl border border-stone-200 bg-white"
      />

      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={clear}
          className="text-xs text-stone-500 underline-offset-4 hover:underline"
        >
          Clear
        </button>
        <Button
          disabled={!dirty}
          onClick={() => {
            const canvas = canvasRef.current;
            if (!canvas) return;
            onCreate(canvas.toDataURL("image/png"));
          }}
        >
          Use signature
        </Button>
      </div>
    </div>
  );
}
