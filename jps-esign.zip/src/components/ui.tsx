"use client";

import { useCallback, useState, type ReactNode } from "react";

export function Card({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`rounded-2xl border border-stone-200 bg-white/70 p-5 shadow-[0_1px_0_rgba(0,0,0,0.02)] ${className}`}
    >
      {children}
    </div>
  );
}

export function Button({
  children,
  onClick,
  variant = "primary",
  disabled,
  type = "button",
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "outline";
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
}) {
  const styles: Record<string, string> = {
    primary:
      "bg-stone-900 text-stone-50 hover:bg-stone-700 disabled:bg-stone-300 disabled:text-stone-500",
    outline:
      "border border-stone-300 text-stone-800 hover:border-stone-900 hover:bg-stone-900/5 disabled:opacity-40",
    ghost: "text-stone-600 hover:bg-stone-900/5 hover:text-stone-900 disabled:opacity-40",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition disabled:cursor-not-allowed ${styles[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

export function Dropzone({
  onFiles,
  accept = "application/pdf",
  multiple = false,
  label = "Drop a PDF here",
  hint = "or click to browse — nothing is uploaded",
}: {
  onFiles: (files: File[]) => void;
  accept?: string;
  multiple?: boolean;
  label?: string;
  hint?: string;
}) {
  const [over, setOver] = useState(false);

  const handleDrop = useCallback(
    (event: React.DragEvent<HTMLLabelElement>) => {
      event.preventDefault();
      setOver(false);
      const files = Array.from(event.dataTransfer.files || []);
      if (files.length) onFiles(multiple ? files : [files[0]]);
    },
    [multiple, onFiles],
  );

  return (
    <label
      onDragOver={(e) => {
        e.preventDefault();
        setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={handleDrop}
      className={`grain flex cursor-pointer flex-col items-center justify-center gap-1 rounded-2xl border border-dashed px-6 py-12 text-center transition ${
        over ? "border-stone-900 bg-stone-900/[0.04]" : "border-stone-300 bg-white/50"
      }`}
    >
      <span className="text-2xl">🗎</span>
      <span className="mt-1 text-sm font-medium text-stone-800">{label}</span>
      <span className="text-xs text-stone-500">{hint}</span>
      <input
        type="file"
        accept={accept}
        multiple={multiple}
        className="hidden"
        onChange={(e) => {
          const files = Array.from(e.target.files || []);
          if (files.length) onFiles(files);
          e.currentTarget.value = "";
        }}
      />
    </label>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1.5 text-xs font-medium uppercase tracking-wide text-stone-500">
      {label}
      {children}
    </label>
  );
}

export const inputClass =
  "w-full rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm font-normal normal-case tracking-normal text-stone-900 outline-none transition focus:border-stone-900";
