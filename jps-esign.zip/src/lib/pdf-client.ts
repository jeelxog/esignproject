"use client";

import type { PDFDocumentProxy } from "pdfjs-dist";

export type PdfJs = typeof import("pdfjs-dist");

let pdfjsPromise: Promise<PdfJs> | null = null;

export async function getPdfJs(): Promise<PdfJs> {
  if (!pdfjsPromise) {
    pdfjsPromise = import("pdfjs-dist").then((mod) => {
      mod.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
      return mod;
    });
  }
  return pdfjsPromise;
}

export async function loadPdfDocument(data: ArrayBuffer): Promise<PDFDocumentProxy> {
  const pdfjs = await getPdfJs();
  return pdfjs.getDocument({ data: data.slice(0) }).promise;
}

export async function renderPageToDataUrl(
  pdf: PDFDocumentProxy,
  pageNumber: number,
  targetWidth = 900,
): Promise<{ url: string; width: number; height: number }> {
  const page = await pdf.getPage(pageNumber);
  const base = page.getViewport({ scale: 1 });
  const scale = targetWidth / base.width;
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement("canvas");
  canvas.width = Math.floor(viewport.width);
  canvas.height = Math.floor(viewport.height);
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas not supported");
  await page.render({ canvasContext: context, viewport }).promise;
  return { url: canvas.toDataURL("image/png"), width: canvas.width, height: canvas.height };
}

export function downloadBlob(bytes: Uint8Array | Blob, filename: string) {
  const blob =
    bytes instanceof Blob
      ? bytes
      : new Blob([new Uint8Array(bytes).buffer as ArrayBuffer], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export async function logActivity(input: {
  name: string;
  tool: string;
  pages?: number;
  sizeBytes?: number;
}) {
  try {
    await fetch("/api/documents", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    });
  } catch {
    /* activity logging is best-effort */
  }
}

export function formatBytes(bytes?: number | null) {
  if (!bytes && bytes !== 0) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function parsePageRanges(input: string, max: number): number[] {
  const out: number[] = [];
  for (const part of input.split(",")) {
    const chunk = part.trim();
    if (!chunk) continue;
    if (chunk.includes("-")) {
      const [a, b] = chunk.split("-").map((v) => Number(v.trim()));
      if (!Number.isFinite(a) || !Number.isFinite(b)) continue;
      const start = Math.max(1, Math.min(a, b));
      const end = Math.min(max, Math.max(a, b));
      for (let i = start; i <= end; i += 1) out.push(i);
    } else {
      const n = Number(chunk);
      if (Number.isFinite(n) && n >= 1 && n <= max) out.push(n);
    }
  }
  return [...new Set(out)].sort((a, b) => a - b);
}
